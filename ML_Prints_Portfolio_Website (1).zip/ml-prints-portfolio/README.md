# ML Prints Portfolio Website

A responsive one-page portfolio website for ML Prints, built with HTML, CSS, and vanilla JavaScript.

## Included
- Home/hero section
- Selected-work portfolio with category filters
- Services section
- About section
- Quote inquiry form that prepares an email
- Mobile navigation and responsive layout

## Before publishing
1. Open `script.js` and replace `YOUR-EMAIL@example.com` with your actual business email.
2. Replace the illustrative CSS portfolio preview cards in `index.html` with photographs/screenshots of your real finished work when available.
3. Add your preferred phone number, social media links, and business address if you want them shown.
4. Open `index.html` in a browser to preview the website.

No framework or build step is required. Upload the contents of this folder to any static web host.
