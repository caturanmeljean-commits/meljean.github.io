const toggle = document.getElementById('menuToggle');
const nav = document.getElementById('nav');
toggle.addEventListener('click', () => {
  const open = nav.classList.toggle('open');
  toggle.setAttribute('aria-expanded', String(open));
  toggle.textContent = open ? '×' : '☰';
});
nav.querySelectorAll('a').forEach(link => link.addEventListener('click', () => {
  nav.classList.remove('open');
  toggle.setAttribute('aria-expanded', 'false');
  toggle.textContent = '☰';
}));
document.querySelectorAll('.filter').forEach(button => {
  button.addEventListener('click', () => {
    document.querySelectorAll('.filter').forEach(item => item.classList.remove('active'));
    button.classList.add('active');
    const filter = button.dataset.filter;
    document.querySelectorAll('.work-card').forEach(card => {
      card.hidden = filter !== 'all' && card.dataset.category !== filter;
    });
  });
});
document.getElementById('year').textContent = new Date().getFullYear();
document.getElementById('quoteForm').addEventListener('submit', event => {
  event.preventDefault();
  const data = new FormData(event.currentTarget);
  const subject = encodeURIComponent('ML Prints — Project Inquiry: ' + data.get('service'));
  const body = encodeURIComponent(
    'Hello ML Prints,\\n\\nI would like to inquire about a project.\\n\\n' +
    'Name: ' + data.get('name') + '\\n' +
    'Email or phone: ' + data.get('reply') + '\\n' +
    'Service: ' + data.get('service') + '\\n' +
    'Project details: ' + (data.get('details') || 'Not provided') + '\\n\\nThank you!'
  );
  // Replace this placeholder with your real business email before publishing.
  window.location.href = 'mailto:YOUR-EMAIL@example.com?subject=' + subject + '&body=' + body;
});
